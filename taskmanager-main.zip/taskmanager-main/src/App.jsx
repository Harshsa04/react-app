import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import axios from 'axios';

import Navbar from './components/Navbar/navbar';
import AddTask from './components/addtask/addtask';
import Dashboard from './components/Dashboard/Dashboard';
import Completed from './components/Completed/Completed';
import Important from './components/Important/Important';
import InProgress from './components/InProgress/InProgress';
import LoginSignup from './components/loginSignup/loginsignup';

function App() {
  const [tasks, setTasks] = useState([]);

  const fetchTasks = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/tasks', {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`,
        },
      });
      setTasks(res.data);
    } catch (err) {
      console.error('Error fetching tasks', err);
    }
  };

  // Fetch tasks on first load
  useEffect(() => {
    fetchTasks();
  }, []);

  const handleTaskCreate = (newTask) => {
    setTasks((prev) => [...prev, newTask]);
  };

  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginSignup />} />

        <Route
          path="/dashboard"
          element={
            <>
              <Navbar />
              <AddTask onTaskCreate={handleTaskCreate} />
              <Dashboard tasks={tasks} />
            </>
          }
        />
        <Route
          path="/important"
          element={
            <>
              <Navbar />
              <AddTask onTaskCreate={handleTaskCreate} />
              <Important tasks={tasks} />
            </>
          }
        />
        <Route
          path="/completed"
          element={
            <>
              <Navbar />
              <AddTask onTaskCreate={handleTaskCreate} />
              <Completed tasks={tasks} />
            </>
          }
        />
        <Route
          path="/inprogress"
          element={
            <>
              <Navbar />
              <AddTask onTaskCreate={handleTaskCreate} />
              <InProgress tasks={tasks} />
            </>
          }
        />
      </Routes>
    </Router>
  );
}

export default App;
