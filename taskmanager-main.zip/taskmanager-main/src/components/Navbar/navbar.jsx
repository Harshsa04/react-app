import React, { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import './navbar.css';

const Navbar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isLoggedIn, setIsLoggedIn] = useState(!!localStorage.getItem('token'));

  useEffect(() => {
    // Update login status whenever route changes
    setIsLoggedIn(!!localStorage.getItem('token'));
  }, [location]);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    setIsLoggedIn(false);
    navigate('/'); // Redirect to LoginSignup page
  };

  return (
    <nav className="navbar">
      {/* Logo */}
      <div className="navbar__logo">
        <Link to="/">Task<span>manager</span></Link>
      </div>

      {/* Links */}
      <ul className="navbar__links">
        <li><Link to="/dashboard">Dashboard</Link></li>
        <li><Link to="/important">Important</Link></li>
        <li><Link to="/completed">Completed</Link></li>
        <li><Link to="/inprogress">In Progress</Link></li>
      </ul>

      {/* Button */}
      <div className="navbar__buttons">
        {isLoggedIn ? (
          <button className="navbar__buttons__Logout" onClick={handleLogout}>
            Logout
          </button>
        ) : (
          <Link to="/">
            <button className="navbar__buttons__Login">Login</button>
          </Link>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
