import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './loginsignup.css';

const LoginSignup = () => {
  const navigate = useNavigate();

  const [isLogin, setIsLogin] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false); // ✅ track login state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('token');
    setIsLoggedIn(!!token);
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const url = isLogin
      ? 'http://localhost:5000/api/auth/login'
      : 'http://localhost:5000/api/auth/signup';

    const payload = isLogin
      ? { email, password }
      : { username, email, password };

    try {
      const res = await axios.post(url, payload);

      if (res.data.token) {
        localStorage.setItem('token', res.data.token);
        localStorage.setItem('username', res.data.username || '');
        setIsLoggedIn(true);
        navigate('/dashboard');
      }

      alert(isLogin ? 'Login successful!' : 'Signup successful!');
    } catch (err) {
      setError(err.response?.data?.error || 'Something went wrong');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    setIsLoggedIn(false);
    setIsLogin(true);
    navigate('/'); // go back to login page
  };

  return (
    <div className="login-signup-container">
      <div className="left-section">
        <div className="welcome-message">
          <h2>{isLoggedIn ? `Hello, ${localStorage.getItem('username')}` : isLogin ? 'Welcome back!' : 'Create your account'}</h2>
        </div>

        <form className="signup-form" onSubmit={handleSubmit}>
          <h3 className="title">{isLoggedIn ? "Dashboard" : isLogin ? "Login" : "Sign Up"}</h3>
          {error && <p style={{ color: 'red' }}>{error}</p>}

          {!isLoggedIn && !isLogin && (
            <div className="input-container">
              <input
                type="text"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>
          )}

          {!isLoggedIn && (
            <>
              <div className="input-container">
                <input
                  type="email"
                  placeholder="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>

              <div className="input-container">
                <input
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            </>
          )}

          <button
            type={isLoggedIn ? 'button' : 'submit'}
            className="button-submit"
            onClick={isLoggedIn ? handleLogout : undefined}
          >
            {isLoggedIn ? 'Logout' : isLogin ? 'Login' : 'Sign Up'}
          </button>

          {!isLoggedIn && (
            <p className="click-here">
              {isLogin ? "Don't have an account? " : "Already have an account? "}
              <span onClick={() => setIsLogin(!isLogin)}>
                {isLogin ? "Sign Up" : "Login"}
              </span>
            </p>
          )}
        </form>
      </div>
    </div>
  );
};

export default LoginSignup;
