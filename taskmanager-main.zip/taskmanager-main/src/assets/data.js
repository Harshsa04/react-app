export const data = [
    { 
        id: 1, 
        title: 'Task 1', 
        description: 'Description for Task 1', 
        status: 'Completed', 
        important: 'Yes' 
    },
    { 
        id: 2,
        title: 'Task 2', 
        description: 'Description for Task 2', 
        status: 'Inprogress',
        important: 'No' 
    },
    { 
        id: 3, 
        title: 'Task 3', 
        description: 'Description for Task 3', 
        status: 'Completed', 
        important: 'No' 
    },
    { 
        id: 4, 
        title: 'Task 4', 
        description: 'Description for Task 4', 
        status: 'Inprogress', 
        important: 'Yes' 
    },
    { 
        id: 5, 
        title: 'Task 5', 
        description: 'Description for Task 5', 
        status: 'Inprogress', 
        important: 'No' 
    },
    { 
        id: 6, 
        title: 'Task 6', 
        description: 'Description for Task 6', 
        status: 'Completed', 
        important: 'Yes' 
    },
    { 
        id: 7, 
        title: 'Task 7', 
        description: 'Description for Task 7', 
        status: 'Inprogress', 
        important: 'Yes' 
    },
    { 
        id: 8, 
        title: 'Task 8', 
        description: 'Description for Task 8', 
        status: 'Completed', 
        important: 'No' 
    },
    { 
        id: 9, 
        title: 'Task 9', 
        description: 'Description for Task 9', 
        status: 'Inprogress', 
        important: 'Yes' 
    },
    { 
        id: 10, 
        title: 'Task 10', 
        description: 'Description for Task 10', 
        status: 'Completed', 
        important: 'Yes' 
    },
    { 
        id: 11, 
        title: 'Task 11', 
        description: 'Description for Task 11', 
        status: 'Completed', 
        important: 'Yes' 
    },
    { 
        id: 12, 
        title: 'Task 12', 
        description: 'Description for Task 12', 
        status: 'Inprogress', 
        important: 'No' 
    }
];

export default data;